import React from 'react';
import CountriesList from '../components/CountriesList';

function Home() {
  return (
    <body class="bg-black">
    <div className="App">
      <CountriesList />
    </div>
    </body>
  );
}

export default Home;
